package com.discoverfinancial.cds.custtrans;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CusttransApplication {

	public static void main(String[] args) {
		SpringApplication.run(CusttransApplication.class, args);
	}
}
